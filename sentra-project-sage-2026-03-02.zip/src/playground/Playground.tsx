import { ProjectSageTab } from "./ProjectSageTab";
export function Playground() {
  return (
    <div style={{ fontFamily: "var(--font-family)", minHeight: "100vh", background: "var(--bg-subtle, #fafafa)" }}>
      <ProjectSageTab />
    </div>
  );
}
