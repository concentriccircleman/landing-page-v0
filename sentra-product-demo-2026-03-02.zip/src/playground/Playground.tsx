import { ProductTab } from "./ProductTab";
export function Playground() {
  return (
    <div style={{ fontFamily: "var(--font-family)", minHeight: "100vh", background: "var(--bg-subtle, #fafafa)" }}>
      <ProductTab />
    </div>
  );
}
