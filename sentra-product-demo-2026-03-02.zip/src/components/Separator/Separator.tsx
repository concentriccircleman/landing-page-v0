import styles from "./Separator.module.css";

interface SeparatorProps {
  className?: string;
}

export function Separator({ className }: SeparatorProps) {
  return (
    <hr
      className={`${styles.separator} ${className ?? ""}`}
      role="separator"
    />
  );
}
