export { PromptSuggestion } from "./PromptSuggestion";
export type {
  PromptSuggestionProps,
  PromptSuggestionVariant,
  PromptSuggestionSize,
} from "./PromptSuggestion";
