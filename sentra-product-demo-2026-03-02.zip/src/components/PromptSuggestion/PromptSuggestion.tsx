import React from "react";
import styles from "./PromptSuggestion.module.css";

export type PromptSuggestionVariant = "default" | "highlight";
export type PromptSuggestionSize = "sm" | "default";

export interface PromptSuggestionProps {
  highlight?: string;
  variant?: PromptSuggestionVariant;
  size?: PromptSuggestionSize;
  className?: string;
  children?: React.ReactNode;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}

function highlightText(text: string, highlight: string): React.ReactNode {
  if (!highlight || highlight.length === 0) return text;

  const lowerText = text.toLowerCase();
  const lowerHighlight = highlight.toLowerCase();
  const index = lowerText.indexOf(lowerHighlight);

  if (index === -1) return text;

  const before = text.slice(0, index);
  const match = text.slice(index, index + highlight.length);
  const after = text.slice(index + highlight.length);

  return (
    <>
      {before}
      <mark className={styles.highlightMark}>{match}</mark>
      {after}
    </>
  );
}

export function PromptSuggestion({
  highlight,
  variant = "default",
  size = "default",
  className,
  children,
  onClick,
}: PromptSuggestionProps) {
  const textContent =
    typeof children === "string" ? children : String(children ?? "");
  const content =
    variant === "highlight" && highlight
      ? highlightText(textContent, highlight)
      : children;

  const classes = [
    styles.suggestion,
    variant === "default" ? styles.default : styles.highlight,
    size === "sm" ? styles.sizeSm : "",
    className ?? "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <button
      type="button"
      className={classes}
      onClick={onClick}
      aria-label={typeof children === "string" ? children : "Suggestion"}
    >
      {content}
    </button>
  );
}
