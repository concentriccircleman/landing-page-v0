import React, { createContext, useContext, useState } from "react";
import styles from "./Tabs.module.css";

type TabsVariant = "underline" | "pills" | "default";

interface TabsContextValue {
  value: string;
  onValueChange: (value: string) => void;
  variant: TabsVariant;
}

const TabsContext = createContext<TabsContextValue | null>(null);
function useTabsContext() {
  const ctx = useContext(TabsContext);
  if (!ctx) throw new Error("Tabs compound components must be used within <Tabs>");
  return ctx;
}

export interface TabsProps {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  variant?: TabsVariant;
  children: React.ReactNode;
  className?: string;
}

export function Tabs({ value: controlledValue, defaultValue = "", onValueChange, variant = "underline", children, className }: TabsProps) {
  const [internal, setInternal] = useState(defaultValue);
  const value = controlledValue ?? internal;
  const handleChange = (v: string) => { setInternal(v); onValueChange?.(v); };

  return (
    <TabsContext.Provider value={{ value, onValueChange: handleChange, variant }}>
      <div className={[styles.tabs, className ?? ""].filter(Boolean).join(" ")}>{children}</div>
    </TabsContext.Provider>
  );
}

export interface TabsListProps {
  children: React.ReactNode;
  className?: string;
}

export function TabsList({ children, className }: TabsListProps) {
  const { variant } = useTabsContext();
  const variantClass = variant === "pills" ? styles.listPills : variant === "underline" ? styles.listUnderline : styles.listDefault;
  return (
    <div role="tablist" className={[styles.list, variantClass, className ?? ""].filter(Boolean).join(" ")}>
      {children}
    </div>
  );
}

export interface TabsTriggerProps {
  value: string;
  disabled?: boolean;
  children: React.ReactNode;
  className?: string;
}

export function TabsTrigger({ value, disabled, children, className }: TabsTriggerProps) {
  const ctx = useTabsContext();
  const isActive = ctx.value === value;
  const variantClass = ctx.variant === "pills" ? styles.triggerPills : ctx.variant === "underline" ? styles.triggerUnderline : styles.triggerDefault;

  return (
    <button
      role="tab"
      type="button"
      aria-selected={isActive}
      disabled={disabled}
      className={[styles.trigger, variantClass, isActive ? styles.triggerActive : "", disabled ? styles.triggerDisabled : "", className ?? ""].filter(Boolean).join(" ")}
      onClick={() => !disabled && ctx.onValueChange(value)}
    >
      {children}
    </button>
  );
}

export interface TabsContentProps {
  value: string;
  children: React.ReactNode;
  className?: string;
}

export function TabsContent({ value, children, className }: TabsContentProps) {
  const ctx = useTabsContext();
  if (ctx.value !== value) return null;
  return (
    <div role="tabpanel" className={[styles.content, className ?? ""].filter(Boolean).join(" ")}>
      {children}
    </div>
  );
}
