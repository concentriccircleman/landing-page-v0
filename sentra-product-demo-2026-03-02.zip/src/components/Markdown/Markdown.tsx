import React from "react";
import styles from "./Markdown.module.css";

export interface MarkdownProps {
  content: string;
  className?: string;
}

type Block =
  | { type: "h1"; text: string }
  | { type: "h2"; text: string }
  | { type: "h3"; text: string }
  | { type: "p"; text: string }
  | { type: "blockquote"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] }
  | { type: "pre"; text: string }
  | { type: "hr" };

function parseBlocks(content: string): Block[] {
  const blocks: Block[] = [];
  const lines = content.split(/\r?\n/);
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // Horizontal rule
    if (/^---+$/.test(line.trim())) {
      blocks.push({ type: "hr" });
      i++;
      continue;
    }

    // Headings
    const h1Match = line.match(/^#\s+(.+)$/);
    if (h1Match) {
      blocks.push({ type: "h1", text: h1Match[1].trim() });
      i++;
      continue;
    }
    const h2Match = line.match(/^##\s+(.+)$/);
    if (h2Match) {
      blocks.push({ type: "h2", text: h2Match[1].trim() });
      i++;
      continue;
    }
    const h3Match = line.match(/^###\s+(.+)$/);
    if (h3Match) {
      blocks.push({ type: "h3", text: h3Match[1].trim() });
      i++;
      continue;
    }

    // Blockquote
    if (line.startsWith("> ")) {
      const quoteLines: string[] = [];
      while (i < lines.length && lines[i].startsWith("> ")) {
        quoteLines.push(lines[i].slice(2));
        i++;
      }
      blocks.push({ type: "blockquote", text: quoteLines.join("\n") });
      continue;
    }

    // Unordered list
    if (line.match(/^-\s+/)) {
      const items: string[] = [];
      while (i < lines.length && lines[i].match(/^-\s+/)) {
        items.push(lines[i].replace(/^-\s+/, ""));
        i++;
      }
      blocks.push({ type: "ul", items });
      continue;
    }

    // Ordered list
    if (line.match(/^\d+\.\s+/)) {
      const items: string[] = [];
      while (i < lines.length && lines[i].match(/^\d+\.\s+/)) {
        items.push(lines[i].replace(/^\d+\.\s+/, ""));
        i++;
      }
      blocks.push({ type: "ol", items });
      continue;
    }

    // Fenced code block
    if (line.trim().startsWith("```")) {
      const fence = line.trim().slice(0, 3);
      const preLines: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith("```")) {
        preLines.push(lines[i]);
        i++;
      }
      if (i < lines.length) i++;
      blocks.push({ type: "pre", text: preLines.join("\n") });
      continue;
    }

    // Paragraph
    if (line.trim()) {
      const pLines: string[] = [];
      while (i < lines.length && lines[i].trim() && !lines[i].match(/^#+\s/) && !lines[i].startsWith("> ") && !lines[i].match(/^-\s+/) && !lines[i].match(/^\d+\.\s+/) && !lines[i].trim().startsWith("```")) {
        pLines.push(lines[i]);
        i++;
      }
      blocks.push({ type: "p", text: pLines.join("\n").trim() });
      continue;
    }

    i++;
  }

  return blocks;
}

function parseInline(text: string): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  let remaining = text;
  let key = 0;

  while (remaining.length > 0) {
    // Links [text](url)
    const linkMatch = remaining.match(/\[([^\]]+)\]\(([^)]+)\)/);
    // Bold **text**
    const boldMatch = remaining.match(/\*\*([^*]+)\*\*/);
    // Italic *text*
    const italicMatch = remaining.match(/(?<!\*)\*([^*]+)\*(?!\*)/);
    // Code `code`
    const codeMatch = remaining.match(/`([^`]+)`/);

    const matches = [
      linkMatch ? { type: "link" as const, match: linkMatch, index: remaining.indexOf(linkMatch[0]) } : null,
      boldMatch ? { type: "bold" as const, match: boldMatch, index: remaining.indexOf(boldMatch[0]) } : null,
      italicMatch ? { type: "italic" as const, match: italicMatch, index: remaining.indexOf(italicMatch[0]) } : null,
      codeMatch ? { type: "code" as const, match: codeMatch, index: remaining.indexOf(codeMatch[0]) } : null,
    ].filter(Boolean) as { type: string; match: RegExpMatchArray; index: number }[];

    const earliest = matches.length > 0 ? matches.reduce((a, b) => (a.index <= b.index ? a : b), matches[0]) : null;

    if (!earliest || earliest.index > 0) {
      const plainEnd = earliest ? earliest.index : remaining.length;
      const plain = remaining.slice(0, plainEnd);
      if (plain) nodes.push(plain);
      remaining = earliest ? remaining.slice(plainEnd) : "";
      if (!earliest) break;
    }

    if (earliest.type === "link") {
      nodes.push(
        <a key={key++} href={earliest.match[2]} target="_blank" rel="noopener noreferrer">
          {parseInline(earliest.match[1])}
        </a>
      );
      remaining = remaining.slice(earliest.match[0].length);
    } else if (earliest.type === "bold") {
      nodes.push(<strong key={key++}>{parseInline(earliest.match[1])}</strong>);
      remaining = remaining.slice(earliest.match[0].length);
    } else if (earliest.type === "italic") {
      nodes.push(<em key={key++}>{parseInline(earliest.match[1])}</em>);
      remaining = remaining.slice(earliest.match[0].length);
    } else if (earliest.type === "code") {
      nodes.push(<code key={key++}>{earliest.match[1]}</code>);
      remaining = remaining.slice(earliest.match[0].length);
    }
  }

  return nodes.length === 1 ? nodes[0] : nodes;
}

export const Markdown: React.FC<MarkdownProps> = ({ content, className }) => {
  const blocks = parseBlocks(content);

  const classes = [styles.root, className ?? ""].filter(Boolean).join(" ");

  return (
    <div className={classes}>
      {blocks.map((block, i) => {
        switch (block.type) {
          case "h1":
            return <h1 key={i}>{parseInline(block.text)}</h1>;
          case "h2":
            return <h2 key={i}>{parseInline(block.text)}</h2>;
          case "h3":
            return <h3 key={i}>{parseInline(block.text)}</h3>;
          case "p":
            return <p key={i}>{parseInline(block.text)}</p>;
          case "blockquote":
            return <blockquote key={i}>{parseInline(block.text)}</blockquote>;
          case "ul":
            return (
              <ul key={i}>
                {block.items.map((item, j) => (
                  <li key={j}>{parseInline(item)}</li>
                ))}
              </ul>
            );
          case "ol":
            return (
              <ol key={i}>
                {block.items.map((item, j) => (
                  <li key={j}>{parseInline(item)}</li>
                ))}
              </ol>
            );
          case "pre":
            return (
              <pre key={i}>
                <code>{block.text}</code>
              </pre>
            );
          case "hr":
            return <hr key={i} />;
          default:
            return null;
        }
      })}
    </div>
  );
};

Markdown.displayName = "Markdown";
