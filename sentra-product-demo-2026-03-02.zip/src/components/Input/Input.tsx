import { forwardRef } from "react";
import styles from "./Input.module.css";

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  variant?: "default" | "brand";
  size?: "sm" | "default" | "lg";
  error?: boolean;
  className?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      variant = "default",
      size = "default",
      error = false,
      className,
      disabled,
      ...rest
    },
    ref
  ) => {
    const sizeClass =
      size === "sm" ? styles.sizeSm : size === "lg" ? styles.sizeLg : styles.sizeDefault;

    const rootClasses = [
      styles.input,
      sizeClass,
      variant === "brand" ? styles.brand : undefined,
      error ? styles.error : undefined,
      className,
    ]
      .filter(Boolean)
      .join(" ");

    return (
      <input
        ref={ref}
        className={rootClasses}
        disabled={disabled}
        aria-invalid={error}
        {...rest}
      />
    );
  }
);

Input.displayName = "Input";
