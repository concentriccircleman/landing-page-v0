import React from "react";
import styles from "./Breadcrumb.module.css";

export interface BreadcrumbProps extends React.HTMLAttributes<HTMLElement> {
  className?: string;
}

export function Breadcrumb({ className, ...props }: BreadcrumbProps) {
  return <nav aria-label="breadcrumb" className={[styles.breadcrumb, className ?? ""].filter(Boolean).join(" ")} {...props} />;
}

export interface BreadcrumbListProps extends React.OlHTMLAttributes<HTMLOListElement> {
  className?: string;
}

export function BreadcrumbList({ className, ...props }: BreadcrumbListProps) {
  return <ol className={[styles.list, className ?? ""].filter(Boolean).join(" ")} {...props} />;
}

export interface BreadcrumbItemProps extends React.LiHTMLAttributes<HTMLLIElement> {
  className?: string;
}

export function BreadcrumbItem({ className, ...props }: BreadcrumbItemProps) {
  return <li className={[styles.item, className ?? ""].filter(Boolean).join(" ")} {...props} />;
}

export interface BreadcrumbLinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  className?: string;
}

export function BreadcrumbLink({ className, ...props }: BreadcrumbLinkProps) {
  return <a className={[styles.link, className ?? ""].filter(Boolean).join(" ")} {...props} />;
}

export interface BreadcrumbPageProps extends React.HTMLAttributes<HTMLSpanElement> {
  className?: string;
}

export function BreadcrumbPage({ className, ...props }: BreadcrumbPageProps) {
  return <span role="link" aria-disabled="true" aria-current="page" className={[styles.page, className ?? ""].filter(Boolean).join(" ")} {...props} />;
}

export interface BreadcrumbSeparatorProps extends React.LiHTMLAttributes<HTMLLIElement> {
  className?: string;
}

export function BreadcrumbSeparator({ children, className, ...props }: BreadcrumbSeparatorProps) {
  return (
    <li role="presentation" aria-hidden="true" className={[styles.separator, className ?? ""].filter(Boolean).join(" ")} {...props}>
      {children ?? (
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path d="M4.5 2.5L7.5 6L4.5 9.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
    </li>
  );
}
