import { type ReactNode } from "react";
import styles from "./Badge.module.css";

export type BadgeVariant =
  | "default"
  | "secondary"
  | "destructive"
  | "success"
  | "warning"
  | "info"
  | "outline";

export type BadgeSize = "sm" | "default";

export interface BadgeProps {
  variant?: BadgeVariant;
  size?: BadgeSize;
  onDismiss?: () => void;
  className?: string;
  children: ReactNode;
}

export function Badge({
  variant = "default",
  size = "default",
  onDismiss,
  className,
  children,
}: BadgeProps) {
  const rootClass = [
    styles.badge,
    styles[variant],
    size === "sm" ? styles.sizeSm : undefined,
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <span className={rootClass}>
      {children}
      {onDismiss && (
        <button
          type="button"
          className={styles.dismissButton}
          onClick={onDismiss}
          aria-label="Dismiss"
        >
          ×
        </button>
      )}
    </span>
  );
}
