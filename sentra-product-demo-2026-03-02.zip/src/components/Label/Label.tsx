import styles from "./Label.module.css";

export interface LabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  disabled?: boolean;
  className?: string;
}

export function Label({ disabled = false, className, ...rest }: LabelProps) {
  const rootClasses = [styles.label, disabled ? styles.disabled : undefined, className]
    .filter(Boolean)
    .join(" ");

  return <label className={rootClasses} {...rest} />;
}
